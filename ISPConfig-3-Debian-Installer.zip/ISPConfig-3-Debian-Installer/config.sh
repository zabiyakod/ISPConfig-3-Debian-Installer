#!/bin/bash
# Install Default Variable Definitions

# Default Distribution
DISTRIBUTION=none

# Library Path
LIBRARYPATH=libraries

# Function Path
FUNCTIONPATH=functions

# Extras Path
EXTRAPATH=extras