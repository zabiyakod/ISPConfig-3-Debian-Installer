<?php

$function_list['client_get_all,client_get,client_add,client_update,client_delete,client_get_sites_by_user,client_get_by_username,client_change_password,client_get_id,client_delete_everything'] = 'Client functions';
$function_list['domains_domain_get,domains_domain_add,domains_domain_delete,domains_get_all_by_user'] = 'Domaintool functions';


?>
