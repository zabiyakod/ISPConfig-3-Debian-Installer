#!/bin/bash

php -q /usr/local/ispconfig/server/scripts/ispconfig_update.php